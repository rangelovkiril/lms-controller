import Trajectories from "@/components/data-management/Trajectories";

export default function TrajectoriesPage() {
  return <Trajectories />;
}
